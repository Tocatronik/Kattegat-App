export default {
  plugins: {},
}